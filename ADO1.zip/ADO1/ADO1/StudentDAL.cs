﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ADO1
{
    public class StudentDAL
    {
        List<student> stdlist = new List<student>();
        
        public List <student>ViewAllEmployees()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=pubs;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * From student2";
            cmd.Connection = con;
            con.Open();

            SqlDataReader dr = cmd.ExecuteReader();

            if(dr.HasRows)
            {
                while(dr.Read())
                {
                    student st = new student();
                    st.student_id = int.Parse(dr["student_id"].ToString());
                    st.student_name = dr["student_name"].ToString();
                    st.student_address = dr["student_address"].ToString();
                    st.city = dr["city"].ToString();
                    stdlist.Add(st);
                }
            }
            con.Close();
            return stdlist;

        }
        public int Addstudent(student stnd)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=pubs;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Insert into student2(student_id,student_name,student_address,city)values(@id,@name,@address,@city);Select SCOPE_IDENTITY";
            cmd.Parameters.AddWithValue("@id",stnd.student_id);
            cmd.Parameters.AddWithValue("@name",stnd.student_name);
            cmd.Parameters.AddWithValue("@address", stnd.student_address);
            cmd.Parameters.AddWithValue("@city",stnd.city);
            cmd.Connection = con;
            con.Open();
            int stu_id = int.Parse(cmd.ExecuteScalar().ToString());
            return stu_id;

            con.Close();
      
            //if (rowcount == 1)
            //{
                //Response.Write("Record Inserted....!!");
            //}
        }
        public bool updatestudent(student stnd)
        {
            bool Isupdated = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=pubs;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Insert into student2(student_id,student_name,student_address,city)values(@id,@name,@address,@city)";
            cmd.Parameters.AddWithValue("@id", stnd.student_id);
            cmd.Parameters.AddWithValue("@name", stnd.student_name);
            cmd.Parameters.AddWithValue("@address", stnd.student_address);
            cmd.Parameters.AddWithValue("@city", stnd.city);
            cmd.Connection = con;
            con.Open();
            int stu_id = int.Parse(cmd.ExecuteScalar().ToString());
            int rowcount = cmd.ExecuteNonQuery();
            
            if (rowcount==1)
            {
                Isupdated = true;

            }
            return Isupdated;

            con.Close();
            
        }
        public bool DeleteEmployee(int stdID)
        {
            bool IsDeleted = false;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=pubs;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Delete From student2 where student_id=@id";
            cmd.Parameters.AddWithValue("@id", stdID);
            con.Open();
            cmd.Connection = con;
          
            int rowcount = cmd.ExecuteNonQuery();
           
            if (rowcount == 1)
            {
                IsDeleted = true;
            }
            return IsDeleted;
            con.Close();
        }

        public student StudentsearchID(int stdID)
        {
            student st = new student();

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=pubs;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * from student2 where student_id=@id";
            cmd.Parameters.AddWithValue("@id",stdID);

            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                st.student_name= dr["student_name"].ToString();
               st.student_address = dr["student_address"].ToString();
               st.city = dr["city"].ToString();
               
               
            }
     return st;
            con.Close();

            
        }
    }
    }
