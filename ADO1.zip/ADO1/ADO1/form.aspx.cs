﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ADO1
{
    public partial class form : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=pubs;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * From student2";
            cmd.Connection = con;
            con.Open();
      
            SqlDataReader dr = cmd.ExecuteReader();
          
            GridView1.DataSource = dr;
            GridView1.DataBind();
            con.Close();
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btninsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=pubs;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Insert into student2(student_name,student_address,city)values(@name,@address,@city)";
 
            cmd.Parameters.AddWithValue("@name", txtname.Text);
            cmd.Parameters.AddWithValue("@address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
    
            cmd.Connection = con;
            con.Open();

            int rowcount = cmd.ExecuteNonQuery();
          
            if(rowcount==1)
            {
                Response.Write ("Record Inserted....!!");
            }
            else
            {
                Response.Write("NOT UPDATED");
            }
            con.Close();
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=pubs;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Update student2 Set student_name=@name,student_address=@address,city=@city where student_id=@id";
           cmd.Parameters.AddWithValue("@id", txtID.Text);
            cmd.Parameters.AddWithValue("@name", txtname.Text);
            cmd.Parameters.AddWithValue("@address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowcount == 1)
            {
                Response.Write("Record Updated....!!");
            }
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=pubs;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Delete From student2 where student_id=@id";
            cmd.Parameters.AddWithValue("@id", txtID.Text);
            
            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowcount == 1)
            {
                Response.Write("Record Deleted...!!");
            }
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=pubs;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * from student2 where student_id=@id";
            cmd.Parameters.AddWithValue("@id", txtID.Text);

            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.HasRows)
            {
                dr.Read();
                txtname.Text = dr["student_name"].ToString();
                txtaddress.Text = dr["student_address"].ToString();
                txtcity.Text = dr["city"].ToString();
                
            }
            else
            {
                txtname.Text = " ";
                txtaddress.Text = " ";
                txtcity.Text = " ";
                Response.Write("No records found.........!!!!!!!");
            }
            
        }
    }
}