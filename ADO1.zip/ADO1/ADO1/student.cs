﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADO1
{
    public class student
    {
        public int student_id{ get; set; }
        public string student_name { get; set; }
        public string student_address { get; set; }
        public string city { get; set; }
    }

}