﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        public bool AddAsset(Asset obj)
        {
            bool Isupdated = true;
            if (obj != null)
            {
               

                string s1 = obj.AssetType[0].ToString() + obj.AssetType[1].ToString();

                Random rd = new Random();
                int randomnumber = rd.Next(1,1000);
                s1 = s1 + randomnumber.ToString();
                obj.SerialNo = s1;
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Insert into Asset(AssetType,SerialNo,ProcurementDate,TaggingStatus)values(@at,@sn,GetDate(),'Free Pool')";
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("@sn", obj.SerialNo);
                //cmd.Parameters.AddWithValue("@pd", obj.ProcurementDate);
                //cmd.Parameters.AddWithValue("@ts", obj.TaggingStatus);
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if(rowcount==1)
                {
                    return Isupdated;
                }
                else
                {
                    return false;
                }

            }
            return false;
        }

        public bool ModifyAsset(Asset obj)
        {
            bool Isupdated = true;
            if (obj != null)
            {


                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Update Asset Set AssetType=@at,SerialNo=@sn,ProcurementDate=@pd,TaggingStatus=@ts where AssetID=@aid";
                cmd.Parameters.AddWithValue("@sid", obj.AssetID);
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("@sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("@pd", obj.ProcurementDate);
                cmd.Parameters.AddWithValue("@ts", obj.TaggingStatus);
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    return Isupdated;
                }
                else
                {
                    return false;
                }

            }
            return false;
        }

        public bool TagAsset(AssetTagging obj)
        {
            throw new NotImplementedException();
        }

        public bool DeTagAsset(int intAssetId)
        {
            throw new NotImplementedException();
        }
    }
}
