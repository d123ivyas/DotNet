﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        public bool AddAsset(Asset obj)
        {
            bool Isadded = false;
            //throw new NotImplementedException();
            if (obj != null)
            {
                string s = null;
                Random rand = new Random();
                int i = rand.Next(1, 1000);

                s += obj.AssetType[0].ToString() + obj.AssetType[1].ToString() + i.ToString();
                obj.SerialNo = s;

                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Asset values(@at,@sn,@pd,@ts)";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("@sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("@pd", DateTime.Now);
                cmd.Parameters.AddWithValue("@ts", "FREE POOL");
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    Isadded = true;
                }
                else
                {
                    Isadded = false;
                }
            }
            else
            {
                Isadded = false;
            }
            return Isadded;
        }

        public bool ModifyAsset(Asset obj)
        {
            bool Ismodify = false;
            //  throw new NotImplementedException();
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update Asset set SerialNo=@sn,AssetType=@at,ProcurementDate=@pd where AssetID=@aid";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("@pd", DateTime.Now);
                cmd.Parameters.AddWithValue("@aid", obj.AssetID);
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    Ismodify = true;
                }
                else
                {
                    Ismodify = false;
                }
            }
            else
            {
                Ismodify = false;
            }
            return Ismodify;
        }

        public bool TagAsset(AssetTagging obj)
        {
            bool IsTagged = false;
            string status = "";

            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select TaggingStatus from Asset where AssetId=@aid";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@aid", obj.AssetID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    status = dr["TaggingStatus"].ToString().ToUpper();
                    if (status == "FREE POOL")
                    {
                        SqlConnection con1 = new SqlConnection(ConnectionString);
                        SqlCommand cmd1 = new SqlCommand();
                        cmd1.CommandText = "Insert into AssetTagging values(@eid,@aid,@td,null)";
                        cmd1.Connection = con1;
                        cmd1.Parameters.AddWithValue("@aid", obj.AssetID);
                        cmd1.Parameters.AddWithValue("@eid", obj.EmployeeID);
                        cmd1.Parameters.AddWithValue("@td", DateTime.Now);
                        con1.Open();
                        int rows = cmd1.ExecuteNonQuery();
                        con1.Close();
                        if (rows > 0)
                        {
                            SqlConnection con2 = new SqlConnection(ConnectionString);
                            SqlCommand cmd2 = new SqlCommand();
                            cmd2.CommandText = "update Asset set TaggingStatus=@ts where AssetID=@aid";
                            cmd2.Connection = con2;
                            cmd2.Parameters.AddWithValue("@ts", "Tagged");
                            cmd2.Parameters.AddWithValue("@aid", obj.AssetID);
                            con2.Open();
                            int rows2 = cmd2.ExecuteNonQuery();
                            con2.Close();
                            IsTagged = true;


                        }


                    }
                }
                con.Close();
            }

            return IsTagged;
        }


        public bool DeTagAsset(int intAssetId)
        {
            //throw new NotImplementedException();
            bool IsDetaged = false;
            if (intAssetId == 0)
            {
                IsDetaged = false;
            }
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update AssetTagging set ReleaseDate=@rd where AssetID=@aid";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@rd", DateTime.Now);
                cmd.Parameters.AddWithValue("@aid", intAssetId);
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();
                if (rows > 0)
                {
                    IsDetaged = true;
                }
                else
                {
                    IsDetaged = false;
                }
                if (IsDetaged == true)
                {

                    SqlConnection con1 = new SqlConnection(ConnectionString);
                    SqlCommand cmd1 = new SqlCommand();
                    cmd1.CommandText = "update Asset set TaggingStatus=@ts where AssetID=@aid";
                    cmd1.Connection = con;
                    cmd1.Parameters.AddWithValue("@ts", "Free Pool");
                    cmd1.Parameters.AddWithValue("@aid", intAssetId);
                    con.Open();
                    int rows2 = cmd1.ExecuteNonQuery();
                    if (rows2 > 0)
                    {
                        IsDetaged = true;
                    }
                    else
                    {
                        IsDetaged = false;
                    }
                }
                else
                {
                    IsDetaged = false;
                }
            }
            return IsDetaged;
        }

    }
}
           
        
   

