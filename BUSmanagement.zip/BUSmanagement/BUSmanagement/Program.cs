﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUSmanagement
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}


/*  using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusManagement
{
    public class Bus : Vehicle
    {
        public  string BusID { set; get; }
        public  string BusName { set; get; }
        public int ServiceNumber { set; get; }
        public string ReservationClass { set; get; }
        public  double TicketPrice { set; get; }
        public Bus() : base()
        {

        }
        public Bus(string Source,string Destination,int Distance,int Duration,string BusID,string BusName,int ServiceNumber,string ReservationClass,double TicketPrice)
        {
            this.Source = Source;
            this.Destination = Destination;
            this.Distance = Distance;
            this.Duration = Duration;
            this.BusID = BusID;
            this.BusName = BusName;
            this.ServiceNumber = ServiceNumber;
            this.ReservationClass = ReservationClass;
            this.TicketPrice = TicketPrice;
        }
    }

}
--------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusManagement
{
    public class BusData
    {
        public List<Bus> BusList { get; set; }

        public BusData()
        {
            BusList = new List<Bus>();
        }

        public string AddBus(Bus objBus)
        {
            
            if (objBus==null)
            {
                return null;

            }
            else
            {
                Utility.BusUtility obj1 = new Utility.BusUtility();
                objBus.BusID = obj1.GenerateBusID(objBus.Source, objBus.Destination, objBus.ServiceNumber);
                objBus.BusName = obj1.GenerateBusName(objBus.Source, objBus.Destination);
                objBus.TicketPrice = obj1.FindTicketPrice(objBus.Distance, objBus.ReservationClass);
                BusList.Add(objBus);

            }
            return objBus.BusID;
        }
    }
}
-----------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusManagement.Utility
{
    public class BusUtility
    {
        public string GenerateBusID(string Source, string Destination, int ServiceNumber)
        {
            string BusId = string.Empty;
            string str = string.Empty;
            if(ServiceNumber>=100)
            {
                str = ServiceNumber.ToString();
            }
            else if(ServiceNumber<100&&ServiceNumber>10)
            {
                str = "0" + ServiceNumber.ToString();
            }
            else
            {
                str = "00" + ServiceNumber.ToString();
            }
            BusId += Source.Substring(0, 1).ToUpper();
            BusId += Destination.Substring(0, 1).ToUpper();
            BusId += "-";
            BusId += str;
            return BusId;
        }

        public string GenerateBusName(string Source, string Destination)
        {
          
            string busname = string.Empty;
            busname += Source.Substring(0, 1).ToUpper();
            busname += Source.Substring(1, 1).ToLower();
            busname += Source.Substring(2, 1).ToUpper();
            busname += "-";
            busname += Destination.Substring(0, 1).ToUpper();
            busname += Destination.Substring(1, 1).ToLower();
            busname += Destination.Substring(2, 1).ToUpper();
            return busname;
        }

        public double FindTicketPrice(int Distance, string ReservationClass)
        {
            double price = 0.0;
            if(string.Compare(ReservationClass,"AC")==0)
            {
                price = Distance * 3.5;
            }
            else
            {
                price = Distance * 2;
            }
            return price; 
        }
    }
}
-------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusManagement
{
    public class Vehicle
    {
         public string Source { set; get; }
         public string Destination { set; get; }
         public int Distance { set; get; }
         public  int Duration { set; get; }
        public Vehicle()
        {

        }
        public Vehicle(string Source,string Destination,int Distance,int Duration )
        {
            this.Source = Source;
            this.Destination = Destination;
            this.Distance = Distance;
            this.Duration = Duration;
        }
    }
   

}
-----------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusManagement
{
    class Program
    {
        static void Main(string[] args)
        {            

        }
    }
}
*/
