﻿using System;


namespace MovieTicketing
{
    public class Tickets
    {
       //TODO: Write code here.
    }
}
