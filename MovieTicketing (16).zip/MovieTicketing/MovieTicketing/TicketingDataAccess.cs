﻿using System;
using System.Data.SqlClient;

namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";

        public bool AddMovie(Movies obj)
        {
            bool Isupdated = false;
            if (obj != null)
            {
             
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert into Movies(MovieName,Director,PlaysPerDay,TicketPrice)values(@mn,@dir,@ppd,@tp)";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@mn", obj.MovieName);
                cmd.Parameters.AddWithValue("@dir", obj.DirectorName);
                cmd.Parameters.AddWithValue("@ppd", obj.PlaysPerDay);
                cmd.Parameters.AddWithValue("@tp", obj.TicketPrice);
                con.Open();
              
                int rowCount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowCount == 1)
                {
                    Isupdated = true;
                }
                else
                {
                    Isupdated = false;
                }
               
            }
          
            return Isupdated;
        }

        public bool AddTheatre(Theatres obj)
        {

            bool Isupdated = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert into Theatres(TheatreName,SeatingCapacity)values(@tn,@sc)";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@tn", obj.TheatreName);
                cmd.Parameters.AddWithValue("@sc", obj.SeatingCapacity);
                
                con.Open();
               
                int rowCount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowCount == 1)
                {
                    Isupdated = true;
                }
                else
                {
                    Isupdated = false;
                }
            }
         
            return Isupdated;
        }

        public bool AddShow(Shows obj)
        {
            bool Isupdated = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert into Shows (TheatreID,MovieID,StartDate,EndDate,StartTime,EndTime)values(@tid,@mid,@sd,@ed,@st,@et)";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("tid", obj.TheatreID);
                cmd.Parameters.AddWithValue("mid", obj.MovieID);
                cmd.Parameters.AddWithValue("sd", obj.StartDate);
                cmd.Parameters.AddWithValue("ed", obj.EndDate);
                cmd.Parameters.AddWithValue("st", obj.StartTime);
                cmd.Parameters.AddWithValue("et", obj.EndTime);
                con.Open();
                
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    Isupdated = true;
                }
                else
                {
                    Isupdated = false;
                }

            }
         
            return Isupdated;

        }

        public string AddTicket(Tickets obj)
        {
            string moviename = "";
            decimal ticketprice;
            bool Isupdated = false;
            if(obj!=null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                string query = "Select m.MovieName,m.TicketPrice from Movies m JOIN Shows s on m.MovieID=s.MovieID JOIN Tickets t on t.ShowID=s.ShowID where t.ShowID=@sid";
                SqlCommand cmd = new SqlCommand(query,con);
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@sid", obj.ShowID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    dr.Read();
                    moviename = dr["MovieName"].ToString();
                    ticketprice = decimal.Parse(dr["TicketPrice"].ToString());
                }
                else
                {
                    return null;
                }
                con.Close();
                obj.Amount= obj.NumberofPersons * ticketprice;
                string RefrenceCode = obj.CustomerName[0].ToString() + obj.CustomerName[1].ToString() + obj.NumberofPersons.ToString() + moviename[0].ToString()
                    + moviename[1].ToString() + obj.BookingDate.Day.ToString() + obj.BookingDate.Month.ToString();
                Random rd = new Random();
                int randomnumber = rd.Next(1, 1000);
                RefrenceCode = RefrenceCode + randomnumber.ToString();
                obj.ReferenceCode = RefrenceCode.ToUpper();

                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandText = "Insert into Tickets(ShowID,ReferenceCode,CustomerName,BookingDate,Amount,NumberOfPersons,TicketStatus)values(@sid,@rcd,@cn,@bd,@am,@np,@ts)";
                cmd1.Connection = con;
                cmd1.Parameters.AddWithValue("@sid", obj.ShowID);
                cmd1.Parameters.AddWithValue("@rcd", obj.ReferenceCode);
                cmd1.Parameters.AddWithValue("@cn", obj.CustomerName);
                cmd1.Parameters.AddWithValue("@bd", obj.BookingDate);
                cmd1.Parameters.AddWithValue("@am", obj.Amount);
                cmd1.Parameters.AddWithValue("@np", obj.NumberofPersons);
                cmd1.Parameters.AddWithValue("@ts", obj.TicketStatus);
                con.Open();
                int rowcount = cmd1.ExecuteNonQuery();
                if(rowcount==1)
                {
                    return obj.ReferenceCode;
                }
                else
                {
                    return null;
                }
               
            }
            return null;
        }


        public int DeleteMovie(int intMovieID)
        {
            int rowsDel = 0;
            if (intMovieID != 0)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd1 = new SqlCommand("Select ShowID from Shows where MovieID=@mid", con);
                cmd1.Parameters.AddWithValue("@mid", intMovieID);
                con.Open();
                SqlDataReader drr = cmd1.ExecuteReader();
                if (drr.HasRows)
                {

                    while (drr.Read())
                    {
                        int ShowID = int.Parse(drr["ShowID"].ToString());
                        SqlConnection con1 = new SqlConnection(ConnectionString);
                        SqlCommand cmd2 = new SqlCommand("Delete  from Tickets where ShowID=@sid", con1);
                        cmd2.Parameters.AddWithValue("@sid", ShowID);
                        con1.Open();
                        int rows = cmd2.ExecuteNonQuery();
                        rowsDel += rows;
                        con1.Close();
                        if (rowsDel > 0)
                        {
                            SqlConnection con2 = new SqlConnection(ConnectionString);
                            SqlCommand cmd3 = new SqlCommand("Delete from Shows Where ShowID=@sid", con2);
                            cmd3.Parameters.AddWithValue("@sid", ShowID);
                            con2.Open();
                            int rowCount = cmd3.ExecuteNonQuery();
                            rowsDel += rowCount;
                            con2.Close();
                            if (rowCount > 0)
                            {

                                SqlConnection con3 = new SqlConnection(ConnectionString);
                                SqlCommand cmd4 = new SqlCommand("Delete from Movies Where MovieID=@mid", con3);
                                cmd4.Parameters.AddWithValue("@mid", intMovieID);
                                con3.Open();
                                int delrows = cmd4.ExecuteNonQuery();
                                rowsDel += delrows;
                                con3.Close();
                                if (delrows == 1)
                                    return rowsDel;
                                else
                                    return rowsDel;
                            }

                        }

                    }
                }
                con.Close();
                return rowsDel;
            }
            else
                return rowsDel;

        }
    }
}
