﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling
{
    public class Bill
    {

        public int BillingID{ get; set; }
        public int PhoneNumber { get; set; }
        public DateTime BillingDate { get; set; }
        public int Units { get; set; }
        public decimal OutstandingAmount { get; set; }
        public decimal TotalAmount { get; set; }

    }
}
