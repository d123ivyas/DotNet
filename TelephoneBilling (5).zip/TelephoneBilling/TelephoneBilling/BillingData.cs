﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling
{
    public class BillingData
    {
      public List<Bill> Bills { get; set; }

        public BillingData()
        {
            Bills = new List<Bill>();
        }

        public bool GenerateBill(Bill obj)
        {

            bool isAdded = false;
            if(obj==null)
            {
                return false;
            }
            else
            {
                Random ran = new Random();
                obj.BillingID = ran.Next();

                Utility.BillingUtility obj1 = new Utility.BillingUtility();
                obj.TotalAmount = obj1.CalculateBill(obj.Units, obj.OutstandingAmount);
                Bills.Add(obj);
                isAdded = true;
            }
            return isAdded;
        }

        public Bill SearchBill(int intBillingID)
        {

            Bill b = new Bill();
            b = null;
            if(intBillingID<=0)
            {
                return null;
            }
            else
            {
                for(int i=0;i<Bills.Count;i++)
                {
                    if(Bills[i].BillingID==intBillingID)
                    {
                        b = Bills[i];
                    }
                }
            }
            return b;

        }

        public bool UpdateBill(Bill obj)
        {
            bool u = false;
            if(obj==null)
            {
                return false;
            }
            else
            {
                for(int i=0;i<Bills.Count;i++)
                {
                    if(Bills[i].BillingID==obj.BillingID)
                    {
                        Utility.BillingUtility obj1 = new Utility.BillingUtility();
                        obj.TotalAmount = obj1.CalculateBill(obj.Units, obj.OutstandingAmount);

                        obj.BillingDate = DateTime.Now;
                        Bills[i] = obj;
                        u = true;
                    }
                }
                return u;
            }
        }
    }
}
