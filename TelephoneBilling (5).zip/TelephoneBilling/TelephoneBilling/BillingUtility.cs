﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling.Utility
{
    public class BillingUtility
    {
        public decimal CalculateBill(int intNumberOfUnits, decimal decOutstandingAmount = 0.0m)
        {
            decimal chargeunit = 0;
            decimal total = 0;
            try
            {
                if (intNumberOfUnits < 0)
                {
                    throw new TelephoneBilling.Exceptions.InvalidUnitsException("Invalid units. Billable units should be more than or equal to zero (0).");

                }
                else
                 
                    if (intNumberOfUnits <= 250)
                {
                    chargeunit = 1.50m;
                }

                else if (intNumberOfUnits >= 251 && intNumberOfUnits <= 500)
                {
                    chargeunit = 2.50m;
                }

                else if (intNumberOfUnits > 500)
                {
                    chargeunit = 4.00m;
                }
           
                    total = (intNumberOfUnits * chargeunit) + 200 + decOutstandingAmount;
                }
               catch (TelephoneBilling.Exceptions.InvalidUnitsException a)
            {
                throw a;
            }
            
            return total;

        }
    }
}
