﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelephoneBilling.Utility;
using TelephoneBilling.Exceptions;
namespace TelephoneBilling
{
    public class BillingData
    {
        public Bill b { get; set; }
        public List<Bill> Bills { get; set; }        
        BillingUtility billUtil;
       
        public BillingData()
        {
            Bills = new List<Bill>();
        }

        public bool GenerateBill(Bill obj)
        {
            int random1 = 0;
            bool IsBillGenerated = false;
            if(obj==null)
            {
                IsBillGenerated = false;
            }
            else if (obj != null)
            {
                Random random = new Random();
                random1=random.Next();
                obj.BillingID = random1;
                 billUtil= new BillingUtility();
                if (obj.Units < 0)
                {
                    try
                    {
                        throw new InvalidUnitsException("Invalid units. Billable units should be more than or equal to zero (0).");
                    }catch(Exception ex)
                    {
                        throw ex;
                    }
                }
                else if(obj.Units >= 0)
                {
                    obj.TotalAmount = billUtil.CalculateBill(obj.Units, obj.OutstandingAmount);
                    Bills.Add(obj);
                    IsBillGenerated = true;
                }
                
            }

            return IsBillGenerated;
        }

        public Bill SearchBill(int intBillingID)
        {
            b = null;
            if (intBillingID <= 0)
            {
               b = null;
            }
               

            else
            {
                for(int i=0;i<Bills.Count;i++)
                {
                    if (intBillingID == Bills[i].BillingID)
                    {
                        b = Bills[i];
                        break;
                    }
                    else
                    {
                       b = null;
                    }
                        
                }
            }
            return b;
        }

        public bool UpdateBill(Bill obj)
        {
            bool IsUpdated=false;
            if(obj==null)
            {
                IsUpdated = false;
            }
            else
            {
                for(int i=0;i<Bills.Count;i++)
                {
                    if(Bills[i].BillingID==obj.BillingID)
                    {
                        obj.TotalAmount=billUtil.CalculateBill(obj.Units,obj.OutstandingAmount);
                        obj.BillingDate = DateTime.Now;
                        Bills[i] = obj;
                        IsUpdated = true;
                    }
                }
            }
            return IsUpdated;
        }
       
    }
}
